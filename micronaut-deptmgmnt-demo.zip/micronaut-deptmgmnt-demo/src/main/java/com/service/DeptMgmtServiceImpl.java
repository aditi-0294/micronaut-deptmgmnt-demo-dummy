package com.service;

import com.constants.Constants;
import com.fasterxml.jackson.core.type.TypeReference;
import com.model.ObjectFactory;
import com.utils.JsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.*;

public class DeptMgmtServiceImpl implements DeptMgmtService {

    private static final Logger logger = LoggerFactory.getLogger(DeptMgmtServiceImpl.class);

    @Inject
    private JsonUtil jsonUtil;

    List<ObjectFactory> deptMgmntList = new ArrayList<>();

    // get details of all departments
    public List<ObjectFactory> getAllDeptData() {

        deptMgmntList = jsonUtil.fromJson(new TypeReference<List<ObjectFactory>>() {
        });
        return deptMgmntList;
       // return allDeptData;

    }

    // get details of department based on department id.
    @Override
    public ObjectFactory getDeptDataById(int deptId) {

        /*List<ObjectFactory> deptDataById = new ArrayList<>();
        deptDataById = jsonUtil.fromJson(new TypeReference<List<ObjectFactory>>() {
        });*/

        deptMgmntList = jsonUtil.fromJson(new TypeReference<List<ObjectFactory>>() {
        });

        for(ObjectFactory ob : deptMgmntList) {
       // for(ObjectFactory ob : deptDataById) {
            if(ob.getDeptId() == deptId) {
                return ob;
            }
        }
        return null;

    }

    // create new department
    @Override
    public ObjectFactory createNewDepartment(ObjectFactory objectFactory) {

        /*List<ObjectFactory> deptMgmtList = new ArrayList<>();
        deptMgmtList = jsonUtil.fromJson(
                new TypeReference<List<ObjectFactory>>() {
                });*/



        deptMgmntList = jsonUtil.fromJson(new TypeReference<List<ObjectFactory>>() {
        });
       // Optional<Integer> maxDeptId = deptMgmtList.stream()
        Optional<Integer> maxDeptId = deptMgmntList.stream()
                .map(ObjectFactory::getDeptId)
                .max(Integer::compare);

        int nextDeptId = maxDeptId.map(a -> a + 1).orElse(Math.toIntExact(1L));

        objectFactory.setDeptId(nextDeptId);
        //deptMgmtList.add(objectFactory);
        deptMgmntList.add(objectFactory);


        // write dept. list to json file
        //jsonUtil.toJson(deptMgmtList);

        jsonUtil.toJson(deptMgmntList);

        logger.debug("written to json file :- {}", Constants.jsonFile);

        return objectFactory;

        /* incorrect logic :-
        objectFactory.setDeptId(addNewDept.size()+1);
        addNewDept.add(objectFactory);*/

        /*logger.debug("Writing to json file :- ");
        jsonUtil.toJson(objectFactory);
        logger.debug(jsonUtil.toJson(objectFactory));*/

        // return objectFactory;
    }

    // updating dept id
    @Override
    public ObjectFactory updateDepartmentDetails(int deptId, ObjectFactory updateDetails) {

        ObjectFactory ob = getDeptDataById(deptId);

        logger.info("Id in ob is {} and Id from param is {}", ob.getDeptId(), deptId);

        List<ObjectFactory> obLst = new ArrayList<>();
        if(ob.getDeptId() == deptId) {

            // only update dept. name and dept. location
            ob.setDeptName(updateDetails.getDeptName());
            ob.setDeptLocation(updateDetails.getDeptLocation());

            obLst.add(ob);

        }

        // write to json file
        jsonUtil.toJson(obLst);

        return updateDetails;

    }


    // delete department id.
    @Override
    public void deleteDeptDetails(int deptId) {

        ObjectFactory ob = getDeptDataById(deptId);
        deptMgmntList = jsonUtil.fromJson(new TypeReference<List<ObjectFactory>>() {
        });
       // List<ObjectFactory> obList = new ArrayList<>();

        if(ob.getDeptId() == deptId) {
            deptMgmntList.removeIf(d -> d.getDeptId() == deptId);
            logger.debug("new department mgnt list details :- {}", deptMgmntList);
        }

        // update json file
        jsonUtil.toJson(deptMgmntList);

    }

}
