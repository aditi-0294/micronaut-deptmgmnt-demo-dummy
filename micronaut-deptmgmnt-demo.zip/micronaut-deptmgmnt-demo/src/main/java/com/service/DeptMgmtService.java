package com.service;

import com.model.ObjectFactory;

import javax.inject.Singleton;
import java.util.List;

@Singleton
public interface DeptMgmtService {

    // get all department list
    public List<ObjectFactory> getAllDeptData();

    // get data for a particular department
    public ObjectFactory getDeptDataById(int deptId);

    // creating new department details
    public ObjectFactory createNewDepartment(ObjectFactory objectFactory);

    // updating department details
    public ObjectFactory updateDepartmentDetails(int deptId, ObjectFactory objectFactory);

    // deleting the department details
    public void deleteDeptDetails(int deptId);



}
