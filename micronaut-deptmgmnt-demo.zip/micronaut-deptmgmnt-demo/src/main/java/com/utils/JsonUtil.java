package com.utils;

import com.constants.Constants;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Singleton;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

@Singleton
public class JsonUtil {

    private static final Logger logger = LoggerFactory.getLogger(JsonUtil.class);

    public static ObjectMapper mapper = new ObjectMapper();

    // get the file name
    /*public InputStream jsonFileRead(String path) throws FileNotFoundException {
        InputStream input = null;
        if (!path.equals("")) {
            try {
                input = new FileInputStream(this.getClass().getClassLoader().getResource(path).getFile());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return input;

    }*/

    // read the json file
    public String readJsonFile(String path)  {
        File input = null;
        if (!path.equals("")) {
            //input = new File(this.getClass().getClassLoader().getResource(path).getFile());
            try {
                return new String(Files.readAllBytes(Paths.get(path)));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;

    }


    /*public <T> T fromJson(Class<T> type) {
        try {
            logger.debug("file path :- {}", jsonFileRead(Constants.jsonFilePath).toString());
            mapper.configure(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS, true);
            return mapper.readValue(jsonFileRead(Constants.jsonFilePath), type);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }*/

    // read data from the json file
    @SneakyThrows
    public <T> T fromJson(TypeReference <T> typeRefClass) {
        //logger.debug("reading data from file path :- {}", jsonGetFile(Constants.jsonFile).getAbsolutePath());
        // logger.debug("reading data from file path :- {}", Paths.get(readJsonFile(Constants.jsonFile)));
        mapper.configure(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY, true);
        //return mapper.readValue(jsonFileRead(Constants.jsonFilePath), typeRefClass);
        //return mapper.readValue(jsonGetFile(Constants.jsonFile), typeRefClass);
        // return mapper.readValue(readJsonFile(Constants.jsonFile), typeRefClass);
        return mapper.readValue(readJsonFile(Constants.jsonFile), typeRefClass);
    }

    // write data to the json file
    public void toJson(Object objectValue) {
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        try {
            mapper.writerWithDefaultPrettyPrinter().writeValue(new File(Constants.jsonFile), objectValue);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*
    public void toJson(Object objectValue) {
        //  logger.debug("writing data to file path :- {}", jsonGetFile(Constants.jsonWriteFile).getPath());
       // logger.debug("writing data to file path :- {}", readJsonFile(Constants.jsonWriteFile));
       String json = null;
        try {
            mapper.enable(SerializationFeature.INDENT_OUTPUT);
           // mapper.writerWithDefaultPrettyPrinter().writeValue(jsonGetFile(Constants.jsonWriteFile), objectValue);
            // mapper.writerWithDefaultPrettyPrinter().writeValue(new File(readJsonFile(Constants.jsonFile)), objectValue);
           json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(objectValue);

           //mapper.writerWithDefaultPrettyPrinter().writeValue(new File(Constants.jsonWriteFile), objectValue);
           if(objectValue instanceof Object) {
               Files.write(new File(Constants.jsonWriteFile).toPath(), Arrays.asList(json), StandardOpenOption.APPEND);
           }
           else
               Files.write(new File(Constants.jsonWriteFile).toPath(), Arrays.asList(json), StandardOpenOption.CREATE);

          //  return json;
        } catch (IOException e) {
            e.printStackTrace();
        }

      //  return null;
    }*/

    /*public void toJson(String path, Object objectValue) {
        logger.debug("writing data to file path :- {}", Constants.jsonFile);
        String resultJson = null;
        try {
            mapper.writerWithDefaultPrettyPrinter().writeValue(
                    new File(path), objectValue
            );

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/

/*
    public String toJson(ObjectFactory type) {
        *//*mapper.enable(SerializationFeature.INDENT_OUTPUT);
        FileOutputStream output = null;
        try {
            output = new FileOutputStream(this.getClass()
                        .getClassLoader().getResource(Constants.jsonWriteFile)
                        .getFile());
            mapper.writerWithDefaultPrettyPrinter().writeValue(output, type);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // mapper.writerWithDefaultPrettyPrinter().writeValueAsString(output,object);
       // output.close();
        return mapper.toString();*//*


        final String currentJsonArrayAsString;
        try {
            currentJsonArrayAsString = String.valueOf(
                    Files.readAllLines(
                            (Path) jsonFileRead(Constants.jsonWriteFile)));
            FileWriter fileWriter = new FileWriter(path.toFile(), false
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (FileWriter fileWriter = new FileWriter(path.toFile(), false)) {

            JSONObject jsonObject = new JSONObject(objectMapper.writeValueAsString(book));
            JSONArray jsonArray = new JSONArray(currentJsonArrayAsString);
            jsonArray.put(jsonObject);

            fileWriter.write(jsonArray.toString());
        }
    }*/

}
