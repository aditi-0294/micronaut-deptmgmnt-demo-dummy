package com.controller;

import io.micronaut.http.annotation.Controller;

@Controller("/employee-controller")
public class EmployeeController {


}
