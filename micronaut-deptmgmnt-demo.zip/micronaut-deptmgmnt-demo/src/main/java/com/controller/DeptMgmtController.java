package com.controller;

import com.model.ObjectFactory;
import com.service.DeptMgmtService;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

@Controller("/dept-controller")
public class DeptMgmtController {

    private static Logger logger = LoggerFactory.getLogger(DeptMgmtController.class);

    @Inject
    private DeptMgmtService deptMgmtService;

    public DeptMgmtController(DeptMgmtService deptMgmtService) {
        this.deptMgmtService = deptMgmtService;
    }

    // get all department data
    @Get("/getAllDeptData")
    @Produces(MediaType.APPLICATION_JSON)
    public HttpResponse<List<ObjectFactory>> getAllDeptData() {
        logger.info("Calling GET to retrieve all department information ...");
        return HttpResponse.ok(deptMgmtService.getAllDeptData());
    }

    // get department data by id.
    @Get("/getDeptDataById/{deptId}")
    @Produces(MediaType.APPLICATION_JSON)
    public HttpResponse<ObjectFactory> getDeptDataById(@PathVariable("deptId") int deptId) {
        logger.info("Calling GET to retrieve department information based on id ...");
        logger.debug("department id. passed : {}", deptId);
       // logger.debug("department details :- {}", deptMgmtService.getDeptDataById(deptId));
        Optional<ObjectFactory> optional = Optional.ofNullable(
                deptMgmtService.getDeptDataById(deptId)
        );

        if(optional.isPresent())
            return HttpResponse.ok(deptMgmtService.getDeptDataById(deptId));
        else
            return HttpResponse.notFound();
        //return HttpResponse.ok(deptMgmtService.getDeptDataById(deptId));

    }

    // add new department details
    @Post("/addNewDept")
    @Consumes(MediaType.APPLICATION_JSON)
    public HttpResponse<ObjectFactory> createNewDepartment(@Body ObjectFactory objectFactory) {
        logger.info("Calling POST to add new department information ...");
        return HttpResponse.ok(deptMgmtService.createNewDepartment(objectFactory));
    }

    // update dept. details by id.
    @Put("updateDept/{deptId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public HttpResponse<ObjectFactory> updateDeptDataById(@PathVariable("deptId") int deptId, @Body ObjectFactory objectFactory) {
        logger.info("Calling PUT to update department name and dept. location information for a given dept. id ...");
        logger.debug("department id. passed : {}", deptId);
       // return HttpResponse.ok(deptMgmtService.updateDepartmentDetails(deptId, objectFactory));
      //  logger.info("department details :- {}", deptMgmtService.getDeptDataById(deptId));
       Optional<ObjectFactory> optional = Optional.ofNullable(
                deptMgmtService.updateDepartmentDetails(deptId, objectFactory)
        );

        if(optional.isPresent())
            return HttpResponse.ok(deptMgmtService.updateDepartmentDetails(deptId, objectFactory));
        else
            return HttpResponse.notFound();

    }

    // delete department by id.
    @Delete("deleteDept/{deptId}")
    @Produces(MediaType.APPLICATION_JSON)
    public void deleteDeptDataById(@PathVariable ("deptId") int deptId) {
        logger.info("Calling DELETE to delete all department information by id ...");
        logger.debug("department id. passed : {}", deptId);
        /*Optional<ObjectFactory> optional = Optional.ofNullable(
                deptMgmtService.deleteDeptDetails(deptId)
        );*/

        deptMgmtService.deleteDeptDetails(deptId);

    }


}
