package com.controller;

public class HealthCheckController {
}
