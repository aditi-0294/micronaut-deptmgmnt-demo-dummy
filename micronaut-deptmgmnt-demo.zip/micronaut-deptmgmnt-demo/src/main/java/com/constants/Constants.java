package com.constants;

public class Constants {

   public static  String jsonFile = "sampleData/json-files/dept-mgmt.json";
}
