package com.constants;

public class Constants {

    public static String jsonFilePath = "json-files/dept-mgmt.json";
    public static String jsonWriteFile = "json-files/dept-mgmt-write.json";
}
